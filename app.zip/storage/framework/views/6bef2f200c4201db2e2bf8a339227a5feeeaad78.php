<html>
<head>
  <style>
    <link rel="stylesheet" href="<?php echo asset('pdf.css')?>" type="text/css">
    <strong i="7">@page</strong> { margin: 100px 25px; }
    header { position: fixed; top: -26px; left: 0px; right: 0px; background-color: rgb(252, 0, 0); height: 60px; text-align: center}
    footer { position: fixed; bottom: -40px; left: 0px; right: 0px; background-color: rgb(255, 0, 0); height: 50px; }
    p { page-break-after: always; left: 100px;}
    p:last-child { page-break-after: never; }
    h6{margin: 30px 20px; text-align: right;}
    h5{margin: 30px 65px; text-align: justify; }
    h4{margin: 30px 15px; text-align: center;}
    ul{margin: 25px 60px; text-align: justify; text-align: left;}

  </style>
</head>
<body>
  <header>Red Temática de Investigación Por Colaboración <br>__________________________ <br>Desarrollo Organizacional y Empresarial <br></header>
  <footer><img width="100%" src="./logo/logos.png"/> </footer>
  <main>
      <?php $__empty_1 = true; $__currentLoopData = $minutas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $minuta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <br>                      
                    <h6><?php echo e($minuta->lugar); ?>,<?php echo e($minuta->fecha); ?><br></h6>
                    <h5><b>De: </b><?php echo e($minuta->de); ?><br></h5>
                    <h5><b>Para: </b><?php echo e($minuta->para); ?><br></h5>
                    <h5><b>Saludo: </b><?php echo e($minuta->saludo); ?></h5>  
                    <h5><b>Asunto: </b><?php echo e($minuta->asunto); ?><br></h5>
                    <h5><b>Agenda: </b> <?php echo e($minuta->agenda); ?><br></h5>
                    <h5><b>Temas: </b> <?php echo e($minuta->temas); ?><br></h5>
                    <h5><b>Acuerdos: </b><?php echo e($minuta->acuerdos); ?><br></h5>
                    <h5><b>Acciones: </b><?php echo e($minuta->acciones); ?><br></h5>
                    <h4>_____________<br></h4>
                    <h4><?php echo e($minuta->firma); ?><br></h4>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>  
                <?php endif; ?> 

  </main>
</body>
</html><?php /**PATH C:\xampp\htdocs\prueba\resources\views/minutas/pdf.blade.php ENDPATH**/ ?>